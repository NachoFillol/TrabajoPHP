<div class="container">
    <div class="row">
        <div class="col">
            <h1>Error 404 - Not Found</h1>
        </div>
    </div>
</div>